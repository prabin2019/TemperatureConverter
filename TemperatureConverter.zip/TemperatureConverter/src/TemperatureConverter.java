import java.util.Scanner;

public class TemperatureConverter
{

public static void main(String args[])
   {
      
       Scanner kb = new Scanner(System.in);
       System.out.print("Enter a Fahrenheit Temperature : ");
       double T = kb.nextDouble();                   //getting input from 

       Temperature temp = new Temperature(T);           //passing it to constructor 

       temp.setFahrenheit(T);                   //setFahrenheit 

       System.out.println("The temperature you entered in  Fahrenheit is " + temp.getFahrenheit());  
       System.out.println("The temperature in Celsius is " + temp.getCelsius());
       System.out.println("The temperature in Kelvin is " + temp.getKelvin());
   }
}