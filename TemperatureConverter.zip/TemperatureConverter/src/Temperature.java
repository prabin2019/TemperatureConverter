

public class Temperature
{
   double ftemp;
   Temperature(double T)                       //constructor     
   {
       this.ftemp = T;
   }
   public void setFahrenheit(double T)               //setFahrenheit 
   {
       this.ftemp = T;
   }
   public double getFahrenheit()                   //getFahrenheit 
   {
       return ftemp;
   }
   public double getCelsius()                   //to get Celsius
   {
       return (5.0/9.0) * (ftemp - 32.0);
   }
   public double getKelvin()                   //to get Kelvin
   {
       return ((5.0/9.0) * (ftemp - 32.0)) + 273.0;
   }
}
